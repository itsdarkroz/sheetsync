<?php
defined('ABSPATH') || exit;

/** ظاهر صفحه‌های افزونه: محصولات، یکسان‌سازی داده‌ها، تنظیمات. */
class SheetSync_Views {

    const STATES = [
        'new'     => ['جدید', 'info'],
        'changed' => ['تغییر کرده', 'warn'],
        'synced'  => ['همگام', 'ok'],
        'error'   => ['خطا', 'err'],
        'missing' => ['در شیت نیست', 'muted'],
    ];

    /* ================= اجزای مشترک ================= */

    private static function url($page) {
        return admin_url('admin.php?page=' . $page);
    }

    private static function open($active, $title, $subtitle = '') {
        $n = SheetSync_Admin::attention_count();
        $tabs = [
            'sheetsync'           => ['محصولات', 0],
            'sheetsync-reconcile' => ['یکسان‌سازی داده‌ها', $n],
            'sheetsync-settings'  => ['تنظیمات', 0],
        ];
        echo '<div class="wrap ss-wrap"><div class="ss-head"><div><h1>' . esc_html($title) . '</h1>';
        if ($subtitle) {
            echo '<p class="ss-sub">' . esc_html($subtitle) . '</p>';
        }
        echo '</div></div><nav class="ss-tabs">';
        foreach ($tabs as $slug => $t) {
            printf(
                '<a href="%s" class="%s">%s%s</a>',
                esc_url(self::url($slug)),
                $slug === $active ? 'is-active' : '',
                esc_html($t[0]),
                $t[1] ? ' <span class="ss-pill">' . (int) $t[1] . '</span>' : ''
            );
        }
        echo '</nav>';
        SheetSync_Admin::show_notice();
    }

    private static function close() {
        echo '</div>';
    }

    private static function post_form($action, $nonce, $inner, $back = '') {
        $out = '<form method="post" class="ss-inline" action="' . esc_url(admin_url('admin-post.php?action=' . $action)) . '">';
        $out .= wp_nonce_field($nonce, '_wpnonce', true, false);
        if ($back) {
            $out .= '<input type="hidden" name="back" value="' . esc_attr($back) . '">';
        }
        return $out . $inner . '</form>';
    }

    private static function ago($mysql) {
        if (!$mysql) {
            return '—';
        }
        $ts = strtotime($mysql);
        return $ts ? human_time_diff($ts, current_time('timestamp')) . ' پیش' : '—';
    }

    /* ================= صفحه ۱: محصولات ================= */

    public static function products() {
        $p      = SheetSync_Profile::get();
        $snap   = SheetSync_Profile::snapshot();
        $state  = isset($_GET['state']) ? sanitize_key($_GET['state']) : '';
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $paged  = max(1, (int) ($_GET['paged'] ?? 1));
        $per    = 100;
        $rows   = SheetSync_Repo::query($state, $paged, $per, $search);
        $total  = SheetSync_Repo::count($state, $search);
        $counts = SheetSync_Repo::counts();
        $all    = array_sum($counts);
        $last   = get_option('sheetsync_last_fetch', []);
        $st     = SheetSync_Profile::stats($p, $snap);
        $attention = $st['unmapped'] + $st['no_dest'];
        $locked = empty($p['mapping_confirmed']);

        self::open('sheetsync', 'محصولات', 'محصولات شیت را بررسی و آن‌هایی را که می‌خواهید در سایت آپدیت شوند تیک بزنید.');

        // مراحل کار (تا وقتی همه‌چیز آماده نشده)
        $s1 = $p['csv_url'] && SheetSync_Profile::label_for($p, 'sku') !== '';
        $s2 = !$locked && !$attention;
        $s3 = !empty($counts['synced']);
        if (!($s1 && $s2)) {
            echo '<div class="ss-steps">';
            $steps = [
                [$s1, '۱', 'اتصال به شیت', 'آدرس شیت و ستون «شناسه محصول» را تنظیم کنید.', 'sheetsync-settings', 'تنظیمات'],
                [$s2, '۲', 'یکسان‌سازی داده‌ها', 'مشخص کنید هر مقدار شیت معادل کدام مقدار سایت است و تأیید کنید.', 'sheetsync-reconcile', 'شروع'],
                [$s3, '۳', 'آپدیت محصولات', 'محصولات را تیک بزنید و آپدیت کنید.', 'sheetsync', ''],
            ];
            foreach ($steps as $i => $s) {
                $cls = $s[0] ? 'is-done' : (($i === 0 || $steps[$i - 1][0]) ? 'is-current' : '');
                echo '<div class="ss-step ' . $cls . '"><span class="ss-step-n">' . ($s[0] ? '✓' : esc_html($s[1])) . '</span><div><strong>' . esc_html($s[2]) . '</strong><p>' . esc_html($s[3]) . '</p>';
                if ($s[5] && !$s[0]) {
                    echo '<a class="button button-small" href="' . esc_url(self::url($s[4])) . '">' . esc_html($s[5]) . '</a>';
                }
                echo '</div></div>';
            }
            echo '</div>';
        } elseif ($attention) {
            printf('<div class="ss-alert ss-alert-warning">%d مورد در نگاشت نیاز به رسیدگی دارد؛ مقادیر نگاشت‌نشده روی محصولات اعمال نمی‌شوند. <a href="%s">بررسی در یکسان‌سازی داده‌ها</a></div>', $attention, esc_url(self::url('sheetsync-reconcile')));
        }

        // کارت‌های آمار
        echo '<div class="ss-stats">';
        $base = self::url('sheetsync');
        printf('<a class="ss-stat %s" href="%s"><b>%d</b><span>همه</span></a>', $state === '' ? 'is-active' : '', esc_url($base), $all);
        foreach (self::STATES as $k => $meta) {
            if ($k === 'missing' && empty($counts[$k])) {
                continue;
            }
            printf('<a class="ss-stat ss-%s %s" href="%s"><b>%d</b><span>%s</span></a>', esc_attr($meta[1]), $state === $k ? 'is-active' : '', esc_url(add_query_arg('state', $k, $base)), (int) ($counts[$k] ?? 0), esc_html($meta[0]));
        }
        echo '</div>';

        // نوار ابزار
        echo '<div class="ss-toolbar">';
        echo self::post_form('sheetsync_fetch', 'sheetsync_fetch', '<button class="button button-primary">دریافت از گوگل شیت</button>', 'sheetsync');
        echo '<span class="ss-muted">' . (!empty($last['time']) ? 'آخرین دریافت: ' . esc_html(self::ago($last['time'])) : 'هنوز دریافتی انجام نشده') . '</span>';
        echo '<form method="get" class="ss-search"><input type="hidden" name="page" value="sheetsync">';
        if ($state) {
            echo '<input type="hidden" name="state" value="' . esc_attr($state) . '">';
        }
        echo '<input type="search" name="s" value="' . esc_attr($search) . '" placeholder="جستجوی شناسه یا نام…"> <button class="button">جستجو</button></form>';
        echo '</div>';

        // نوار عملیات آپدیت
        echo '<div class="ss-bulk">';
        echo '<button type="button" class="button" id="ss-pick-pending">انتخاب جدید و تغییرکرده‌ها</button> ';
        echo '<button type="button" class="button button-primary" id="ss-apply" ' . ($locked ? 'disabled' : '') . '>آپدیت در سایت <span id="ss-count">(۰)</span></button>';
        if ($locked) {
            echo ' <span class="ss-muted">آپدیت بعد از تأیید نگاشت در «<a href="' . esc_url(self::url('sheetsync-reconcile')) . '">یکسان‌سازی داده‌ها</a>» فعال می‌شود.</span>';
        }
        echo '</div>';
        echo '<div id="ss-progress" class="ss-progress" hidden><div class="ss-bar"><span></span></div><p class="ss-progress-text"></p><div class="ss-result"></div></div>';

        // جدول
        echo '<table class="ss-table"><thead><tr><th class="ss-chk"><input type="checkbox" id="ss-check-all"></th><th>شناسه</th><th>نام در شیت</th><th>وضعیت در شیت</th><th>وضعیت همگام‌سازی</th><th>آخرین آپدیت</th><th>در سایت</th></tr></thead><tbody>';
        if (!$rows) {
            echo '<tr><td colspan="7" class="ss-empty">' . ($all ? 'موردی پیدا نشد.' : 'هنوز محصولی دریافت نشده. بعد از تنظیم اتصال، «دریافت از گوگل شیت» را بزنید.') . '</td></tr>';
        }
        foreach ($rows as $r) {
            $meta = self::STATES[$r->state] ?? [$r->state, 'muted'];
            echo '<tr data-state="' . esc_attr($r->state) . '">';
            echo '<td class="ss-chk"><input type="checkbox" class="ss-row-check" value="' . (int) $r->id . '"></td>';
            echo '<td><code>' . esc_html($r->sku) . '</code></td>';
            echo '<td>' . esc_html($r->title ?: '—') . '</td>';
            echo '<td>' . ($r->sheet_status ? '<span class="ss-badge ss-muted-b">' . esc_html($r->sheet_status) . '</span>' : '—') . '</td>';
            echo '<td><span class="ss-badge ss-b-' . esc_attr($meta[1]) . '">' . esc_html($meta[0]) . '</span>';
            if ($r->state === 'error' && $r->error) {
                echo '<div class="ss-err-text">' . esc_html($r->error) . '</div>';
            }
            if (!empty($r->notes)) {
                $n = count(explode("\n", $r->notes));
                echo '<details class="ss-notes"><summary>' . (int) $n . ' هشدار</summary>' . nl2br(esc_html($r->notes)) . '</details>';
            }
            echo '</td>';
            echo '<td>' . esc_html(self::ago($r->last_synced)) . '</td>';
            echo '<td>';
            if ($r->product_id) {
                echo '<a href="' . esc_url(get_edit_post_link((int) $r->product_id)) . '">ویرایش</a>';
                if (get_post_status((int) $r->product_id) === 'publish') {
                    echo ' · <a href="' . esc_url(get_permalink((int) $r->product_id)) . '" target="_blank">مشاهده</a>';
                } else {
                    echo ' · <em class="ss-muted">پیش‌نویس</em>';
                }
            } else {
                echo '—';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';

        $pages = (int) ceil($total / $per);
        if ($pages > 1) {
            $args = ['page' => 'sheetsync'];
            if ($state) $args['state'] = $state;
            if ($search) $args['s'] = $search;
            echo '<div class="ss-pages">' . wp_kses_post(paginate_links([
                'base' => add_query_arg('paged', '%#%', add_query_arg($args, admin_url('admin.php'))),
                'format' => '', 'current' => $paged, 'total' => $pages,
            ])) . '</div>';
        }
        self::close();
    }

    /* ================= صفحه ۲: یکسان‌سازی داده‌ها ================= */

    private static function check($ok, $text, $extra = '') {
        return '<li class="' . ($ok ? 'is-ok' : 'is-warn') . '"><span class="ss-ico">' . ($ok ? '✓' : '!') . '</span><div>' . $text . $extra . '</div></li>';
    }

    public static function reconcile() {
        $p     = SheetSync_Profile::get();
        $snap  = SheetSync_Profile::snapshot();
        $taxes = SheetSync_Site::taxonomies();
        $allowed = SheetSync_Site::allowed();
        $last  = get_option('sheetsync_last_fetch', []);

        self::open('sheetsync-reconcile', 'یکسان‌سازی داده‌ها', 'مشخص کنید هر مقدار در گوگل شیت، معادل کدام دسته‌بندی، ویژگی یا برچسب در سایت است.');

        // بدون اتصال
        if (!$snap || !$p['columns']) {
            echo '<div class="ss-card ss-center"><h2>ابتدا به شیت وصل شوید</h2><p>برای یکسان‌سازی، افزونه باید ستون‌ها و مقادیر شیت را بخواند.</p>';
            echo '<a class="button button-primary" href="' . esc_url(self::url('sheetsync-settings')) . '">رفتن به تنظیمات</a></div>';
            self::close();
            return;
        }

        $st = SheetSync_Profile::stats($p, $snap);
        $broken = SheetSync_Profile::broken_count($p);
        $legacy = array_filter($taxes, function ($t) { return $t['legacy']; });
        $has_sku = SheetSync_Profile::label_for($p, 'sku') !== '';

        // ---- چک‌لیست وضعیت
        echo '<div class="ss-card"><div class="ss-card-head"><h2>وضعیت یکسان‌سازی</h2><div class="ss-actions">';
        echo self::post_form('sheetsync_detect', 'sheetsync_settings', '<button class="button">بررسی دوباره شیت</button>', 'sheetsync-reconcile');
        echo '</div></div><ul class="ss-checks">';
        echo self::check(true, 'اتصال به شیت برقرار است', '<small>' . (int) ($snap['rows'] ?? 0) . ' ردیف · ' . (int) ($snap['cols'] ?? 0) . ' ستون · آخرین بررسی ' . esc_html(self::ago($snap['time'] ?? '')) . '</small>');
        echo self::check($has_sku, $has_sku ? 'ستون شناسه محصول مشخص است' : 'ستون «شناسه محصول» انتخاب نشده', $has_sku ? '' : ' <a href="' . esc_url(self::url('sheetsync-settings')) . '">انتخاب در تنظیمات</a>');
        echo self::check(!$st['no_dest'], $st['no_dest'] ? $st['no_dest'] . ' ستون فعال هنوز مقصدی در سایت ندارد' : 'همه ستون‌های فعال مقصد دارند');
        echo self::check(!$st['unmapped'], $st['unmapped'] ? '<span id="ss-unmapped-total">' . $st['unmapped'] . '</span> مقدار شیت هنوز نگاشت نشده' : 'همه مقادیر شیت نگاشت شده‌اند', $st['unmapped'] ? '<small>مقدار نگاشت‌نشده روی محصول اعمال نمی‌شود.</small>' : '');
        if ($broken) {
            echo self::check(false, $broken . ' نگاشت به موردی اشاره می‌کند که در سایت حذف شده', '<small>در کارت ستون مربوطه دوباره انتخاب کنید.</small>');
        }
        if ($st['stale']) {
            echo self::check(false, $st['stale'] . ' نگاشت برای مقداری است که دیگر در شیت نیست', '<small>می‌توانید با دکمه ✕ حذفشان کنید.</small>');
        }
        if (!empty($last['dups']) || !empty($last['skipped'])) {
            echo self::check(false, 'در آخرین دریافت: ' . (int) ($last['dups'] ?? 0) . ' ردیف با شناسه تکراری و ' . (int) ($last['skipped'] ?? 0) . ' ردیف بدون شناسه نادیده گرفته شد');
        }
        if ($legacy) {
            echo self::check(false, count($legacy) . ' ویژگی/دسته‌بندی از نسخه آزمایشی قبلی افزونه در سایت مانده', '<small>برای نگاشت پیشنهاد نمی‌شوند؛ اگر لازم نیستند خودتان از «محصولات ← ویژگی‌ها» حذف کنید.</small>');
        }
        echo '</ul>';
        echo '<div class="ss-confirm">';
        if (!empty($p['mapping_confirmed'])) {
            echo '<span class="ss-badge ss-b-ok">نگاشت تأیید شده</span> <span class="ss-muted">آپدیت محصولات فعال است. با تغییر شیت یا سایت، این صفحه را دوباره بررسی کنید.</span>';
        } else {
            echo '<span class="ss-muted">بعد از نگاشت، تأیید کنید تا آپدیت محصولات فعال شود.</span> ';
            echo self::post_form('sheetsync_confirm', 'sheetsync_confirm', '<button class="button button-primary"' . ($has_sku ? '' : ' disabled') . '>تأیید نگاشت و فعال‌سازی آپدیت</button>', 'sheetsync-reconcile');
        }
        echo '</div></div>';

        // ---- کارت هر ستون
        echo '<h2 class="ss-h2">ستون‌های شیت</h2><p class="ss-sub">هر ستون را باز کنید، مقصدش را در سایت انتخاب کنید و معادل مقادیرش را مشخص کنید. ستون‌هایی که لازم ندارید را خاموش کنید.</p>';
        $cards = 0;
        foreach ($p['columns'] as $c) {
            if (in_array($c['target'], SheetSync_Profile::CORE, true)) {
                continue;
            }
            $vals = $snap['columns'][$c['label']]['values'] ?? [];
            if ($c['target'] === 'skip' && !$vals) {
                continue;
            }
            $cards++;
            self::column_card($c, $vals, $p, $allowed);
        }
        if (!$cards) {
            echo '<div class="ss-card ss-center"><p>ستونی برای یکسان‌سازی پیدا نشد. «ستون‌های اصلی» را در تنظیمات بررسی کنید.</p></div>';
        }

        // ---- تعاریف سایت
        echo '<h2 class="ss-h2">تعاریف موجود در سایت</h2><p class="ss-sub">این‌ها آنچه در سایت تعریف شده است. افزونه هیچ‌کدام را نمی‌سازد یا تغییر نمی‌دهد.</p>';
        echo '<div class="ss-site">';
        foreach ($taxes as $slug => $t) {
            $terms = SheetSync_Site::terms($slug);
            echo '<details class="ss-card ss-site-item"><summary><strong>' . esc_html($t['label']) . '</strong> <span class="ss-badge ss-muted-b">' . esc_html(SheetSync_Site::kind_label($t['kind'])) . '</span> <span class="ss-muted">' . count($terms) . ' مقدار · <code>' . esc_html($slug) . '</code></span></summary>';
            if ($t['legacy']) {
                echo '<p class="ss-err-text">ساخته‌شده توسط نسخه آزمایشی قبلی افزونه.</p>';
            }
            if ($terms) {
                echo '<ul class="ss-tree">';
                foreach ($terms as $term) {
                    echo '<li style="margin-inline-start:' . ((int) $term['depth'] * 18) . 'px">' . esc_html($term['name']) . ' <small class="ss-muted">(' . (int) $term['count'] . ')</small></li>';
                }
                echo '</ul>';
            } else {
                echo '<p class="ss-muted">مقداری ندارد.</p>';
            }
            echo '</details>';
        }
        echo '</div>';
        self::close();
    }

    private static function column_card(array $c, array $vals, array $p, array $allowed) {
        $label = $c['label'];
        $map = $p['value_map'][$label] ?? [];
        $enabled = $c['target'] === 'terms';

        // ردیف‌های مقدار: مقادیر فعلی شیت + نگاشت‌های بی‌مصرف
        $rows = [];
        foreach ($vals as $h => $v) {
            $rows[$h] = ['label' => $v['label'], 'count' => $v['count'], 'stale' => false];
        }
        foreach ($map as $h => $e) {
            if (!isset($rows[$h])) {
                $rows[$h] = ['label' => $e['label'], 'count' => 0, 'stale' => true];
            }
        }
        uasort($rows, function ($a, $b) {
            if ($a['stale'] !== $b['stale']) {
                return $a['stale'] ? 1 : -1;
            }
            return strnatcasecmp($a['label'], $b['label']);
        });

        $mapped = 0;
        foreach ($vals as $h => $v) {
            if (!empty($map[$h]['to'])) {
                $mapped++;
            }
        }
        $total = count($vals);
        $pct = $total ? round($mapped / $total * 100) : 0;

        $status = !$enabled ? ['نادیده گرفته می‌شود', 'muted'] : (!$c['dests'] ? ['بدون مقصد', 'warn'] : ($mapped < $total ? [($total - $mapped) . ' نگاشت‌نشده', 'warn'] : ['کامل', 'ok']));

        echo '<details class="ss-card ss-col' . ($enabled ? '' : ' is-off') . '" data-label="' . esc_attr($label) . '"' . (($enabled && $status[1] === 'warn') ? ' open' : '') . '>';
        echo '<summary><span class="ss-col-name">' . esc_html($label) . '</span>';
        if ($c['group']) {
            echo '<span class="ss-badge ss-muted-b">' . esc_html($c['group']) . '</span>';
        }
        echo '<span class="ss-col-meta">' . (int) $total . ' مقدار</span>';
        echo '<span class="ss-mini"><span class="ss-bar"><span style="width:' . (int) $pct . '%"></span></span><small class="ss-prog">' . (int) $mapped . ' از ' . (int) $total . '</small></span>';
        echo '<span class="ss-badge ss-b-' . esc_attr($status[1]) . ' ss-status">' . esc_html($status[0]) . '</span></summary>';

        echo '<div class="ss-col-body">';
        echo '<label class="ss-switch"><input type="checkbox" class="ss-enable" ' . checked($enabled, true, false) . '> <span>این ستون روی محصولات اعمال شود</span></label>';

        echo '<div class="ss-on">';
        echo '<h4><span class="ss-n">۱</span> این ستون به کدام بخش سایت وصل شود؟ <small>(می‌توانید چند مورد انتخاب کنید)</small></h4><div class="ss-chips">';
        foreach ($allowed as $slug => $t) {
            echo '<label class="ss-chip"><input type="checkbox" value="' . esc_attr($slug) . '" ' . checked(in_array($slug, $c['dests'], true), true, false) . '><span>' . esc_html($t['label']) . ' <small>' . esc_html(SheetSync_Site::kind_label($t['kind'])) . '</small></span></label>';
        }
        echo '</div>';

        echo '<h4><span class="ss-n">۲</span> معادل هر مقدار در سایت</h4>';
        if (!$rows) {
            echo '<p class="ss-muted">مقداری در شیت پیدا نشد.</p>';
        } else {
            echo '<div class="ss-filter"><button type="button" class="is-active" data-f="all">همه</button><button type="button" data-f="unmapped">نگاشت‌نشده</button><button type="button" data-f="mapped">نگاشت‌شده</button></div>';
            echo '<table class="ss-vtable"><thead><tr><th>مقدار در شیت</th><th>تعداد محصول</th><th>معادل در سایت</th></tr></thead><tbody>';
            foreach ($rows as $h => $r) {
                $sel = [];
                $broken = false;
                foreach (($map[$h]['to'] ?? []) as $to) {
                    if (SheetSync_Site::term_exists($to['tax'], $to['id'])) {
                        $sel[] = $to['tax'] . '|' . $to['id'];
                    } else {
                        $broken = true;
                    }
                }
                echo '<tr data-hash="' . esc_attr($h) . '" data-label="' . esc_attr($r['label']) . '" class="' . ($r['stale'] ? 'is-stale' : '') . '">';
                echo '<td><span class="ss-dot"></span>' . esc_html($r['label']);
                if ($r['stale']) {
                    echo ' <small class="ss-muted">(دیگر در شیت نیست)</small>';
                }
                if ($broken) {
                    echo ' <small class="ss-err-text">(مقصد قبلی از سایت حذف شده)</small>';
                }
                echo '</td><td>' . (int) $r['count'] . '</td><td class="ss-vals"><div class="ss-sels">';
                $n = max(1, count($sel));
                for ($k = 0; $k < $n; $k++) {
                    echo '<div class="ss-valsel"><select class="ss-term" data-val="' . esc_attr($sel[$k] ?? '') . '"></select>' . ($k ? '<button type="button" class="ss-rm" title="حذف">×</button>' : '') . '</div>';
                }
                echo '</div><button type="button" class="ss-add" title="افزودن معادل دیگر برای این مقدار">+ معادل دیگر</button>';
                if ($r['stale']) {
                    echo ' <button type="button" class="ss-del-row" title="حذف این نگاشت">✕ حذف</button>';
                }
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>'; // .ss-on

        echo '<div class="ss-col-foot"><button type="button" class="button button-primary ss-save-col">ذخیره این ستون</button> <span class="ss-msg"></span></div>';
        echo '</div></details>';
    }

    /* ================= صفحه ۳: تنظیمات ================= */

    public static function settings() {
        $p    = SheetSync_Profile::get();
        $snap = SheetSync_Profile::snapshot();
        $connected = !empty($snap['time']) && $p['columns'];

        self::open('sheetsync-settings', 'تنظیمات', 'اتصال به گوگل شیت، ستون‌های اصلی محصول و قوانین آپدیت.');

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php?action=sheetsync_save_settings')) . '">';
        wp_nonce_field('sheetsync_settings');

        // کارت ۱: اتصال
        echo '<div class="ss-card"><div class="ss-card-head"><h2>اتصال به گوگل شیت</h2>';
        echo $connected
            ? '<span class="ss-badge ss-b-ok">متصل · ' . (int) ($snap['rows'] ?? 0) . ' ردیف، ' . (int) ($snap['cols'] ?? 0) . ' ستون</span>'
            : '<span class="ss-badge ss-muted-b">متصل نیست</span>';
        echo '</div><div class="ss-field"><label>آدرس گوگل شیت</label><input type="url" name="csv_url" value="' . esc_attr($p['csv_url']) . '" class="ss-input" dir="ltr" placeholder="https://docs.google.com/spreadsheets/d/…">';
        echo '<p class="ss-help">لینک «Publish to web» (فرمت CSV) یا لینک عادی شیت. شیت باید برای «هر کسی که لینک دارد» قابل مشاهده باشد.</p></div>';
        echo '<div class="ss-field ss-field-inline"><label>تعداد ردیف‌های هدر</label><input type="number" name="header_rows" min="1" max="5" value="' . (int) $p['header_rows'] . '" class="ss-input ss-sm">';
        echo '<p class="ss-help">۲ یعنی ردیف اول گروه‌بندی (اطلاعات محصول / دسته‌بندی / ویژگی) و ردیف دوم نام ستون‌هاست.</p></div>';
        echo '<div class="ss-actions"><button class="button button-primary" formaction="' . esc_url(admin_url('admin-post.php?action=sheetsync_detect&back=sheetsync-settings')) . '">ذخیره و اتصال به شیت</button> <span class="ss-help">ستون‌ها و مقادیر شیت خوانده می‌شود؛ چیزی در سایت تغییر نمی‌کند.</span></div></div>';

        // کارت ۲: ستون‌های اصلی
        echo '<div class="ss-card"><div class="ss-card-head"><h2>ستون‌های اصلی محصول</h2></div>';
        if (!$p['columns']) {
            echo '<p class="ss-muted">بعد از اتصال به شیت، اینجا ستون‌ها قابل انتخاب می‌شوند.</p>';
        } else {
            $fields = [
                'sku'           => ['شناسه محصول', 'الزامی؛ برای تشخیص محصول تکراری'],
                'name'          => ['نام محصول', ''],
                'regular_price' => ['قیمت', ''],
                'sale_price'    => ['قیمت تخفیفی', ''],
                'stock'         => ['موجودی', ''],
                'status'        => ['وضعیت آپدیت', 'برای تشخیص محصولات پیش‌نویس'],
            ];
            echo '<p class="ss-help">هر فیلد را به یکی از ستون‌های شیت وصل کنید (انتخاب‌های پیش‌فرض از روی نام ستون‌ها حدس زده شده؛ بررسی کنید).</p><div class="ss-grid">';
            foreach ($fields as $f => $meta) {
                $cur = SheetSync_Profile::label_for($p, $f);
                echo '<div class="ss-field"><label>' . esc_html($meta[0]) . ($f === 'sku' ? ' <b class="ss-req">*</b>' : '') . '</label><select name="core[' . esc_attr($f) . ']" class="ss-input"><option value="">— ندارد —</option>';
                foreach ($p['columns'] as $c) {
                    echo '<option value="' . esc_attr($c['label']) . '"' . selected($cur, $c['label'], false) . '>' . esc_html($c['label']) . '</option>';
                }
                echo '</select>' . ($meta[1] ? '<p class="ss-help">' . esc_html($meta[1]) . '</p>' : '') . '</div>';
            }
            echo '</div>';
        }
        echo '</div>';

        // کارت ۳: قیمت و موجودی
        echo '<div class="ss-card"><div class="ss-card-head"><h2>قیمت و موجودی</h2></div><div class="ss-grid">';
        echo '<div class="ss-field"><label>ضریب قیمت</label><input type="number" step="any" name="price_multiplier" value="' . esc_attr($p['price_multiplier']) . '" class="ss-input ss-sm"><p class="ss-help">قیمت شیت × این عدد. اگر قیمت‌ها در شیت کامل نوشته شده‌اند ۱ بگذارید؛ اگر «هزار تومان» است ۱۰۰۰.</p></div>';
        echo '<div class="ss-field"><label>پسوند قیمت</label><input type="text" name="price_suffix" value="' . esc_attr($p['price_suffix']) . '" class="ss-input" placeholder="مثلاً: هر متر"><p class="ss-help">اختیاری؛ کنار قیمت در فروشگاه نمایش داده می‌شود.</p></div>';
        echo '<div class="ss-field"><label>موجودی اعشاری</label><label class="ss-switch"><input type="checkbox" name="decimal_stock" value="1" ' . checked($p['decimal_stock'], 1, false) . '> <span>فعال (مثلاً ۲٫۵ متر)</span></label></div>';
        echo '</div></div>';

        // کارت ۴: قوانین آپدیت
        echo '<div class="ss-card"><div class="ss-card-head"><h2>قوانین آپدیت</h2></div><div class="ss-grid">';
        echo '<div class="ss-field"><label>وضعیتی که محصول را پیش‌نویس می‌کند</label><input type="text" name="draft_values" value="' . esc_attr($p['draft_values']) . '" class="ss-input"><p class="ss-help">اگر ستون «وضعیت آپدیت» یکی از این مقادیر (با ویرگول جدا کنید) باشد، محصول پیش‌نویس می‌شود و کد محصول نامش می‌شود.</p></div>';
        echo '<div class="ss-field"><label>وضعیت سایر محصولات</label><select name="publish_status" class="ss-input">';
        foreach (['publish' => 'منتشر شود', 'draft' => 'پیش‌نویس', 'pending' => 'در انتظار بررسی'] as $k => $l) {
            echo '<option value="' . esc_attr($k) . '"' . selected($p['publish_status'], $k, false) . '>' . esc_html($l) . '</option>';
        }
        echo '</select></div>';
        echo '<div class="ss-field"><label>جداکننده مقادیر چندتایی در یک سلول</label><input type="text" name="delimiter" value="' . esc_attr($p['delimiter']) . '" class="ss-input ss-sm" dir="ltr"><p class="ss-help">هر کاراکتر یک جداکننده است؛ پیش‌فرض ویرگول فارسی و انگلیسی.</p></div>';
        echo '</div><p class="ss-help">سلول خالی در شیت هرگز چیزی را در سایت تغییر نمی‌دهد یا پاک نمی‌کند.</p></div>';

        echo '<div class="ss-savebar"><button class="button button-primary button-large">ذخیره تنظیمات</button></div>';
        echo '</form>';
        self::close();
    }
}
