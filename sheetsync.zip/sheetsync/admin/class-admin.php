<?php
defined('ABSPATH') || exit;

/** منو، هندلرهای فرم و AJAX. ظاهر صفحه‌ها در SheetSync_Views است. */
class SheetSync_Admin {

    const CAP = 'manage_woocommerce';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('admin_post_sheetsync_fetch', [__CLASS__, 'handle_fetch']);
        add_action('admin_post_sheetsync_save_settings', [__CLASS__, 'handle_save_settings']);
        add_action('admin_post_sheetsync_detect', [__CLASS__, 'handle_detect']);
        add_action('admin_post_sheetsync_confirm', [__CLASS__, 'handle_confirm']);
        add_action('wp_ajax_sheetsync_apply', [__CLASS__, 'ajax_apply']);
        add_action('wp_ajax_sheetsync_save_column', [__CLASS__, 'ajax_save_column']);
    }

    /** تعداد مواردی که نیاز به رسیدگی دارند (برای نشانه روی منو). */
    public static function attention_count() {
        $p = SheetSync_Profile::get();
        $snap = SheetSync_Profile::snapshot();
        if (!$snap) {
            return 0;
        }
        $st = SheetSync_Profile::stats($p, $snap);
        return $st['unmapped'] + $st['no_dest'];
    }

    public static function menu() {
        $n = self::attention_count();
        $badge = $n ? ' <span class="awaiting-mod">' . (int) $n . '</span>' : '';
        add_menu_page('همگام‌سازی شیت', 'همگام‌سازی شیت' . $badge, self::CAP, 'sheetsync', ['SheetSync_Views', 'products'], 'dashicons-update', 56);
        add_submenu_page('sheetsync', 'محصولات', 'محصولات', self::CAP, 'sheetsync', ['SheetSync_Views', 'products']);
        add_submenu_page('sheetsync', 'یکسان‌سازی داده‌ها', 'یکسان‌سازی داده‌ها' . $badge, self::CAP, 'sheetsync-reconcile', ['SheetSync_Views', 'reconcile']);
        add_submenu_page('sheetsync', 'تنظیمات', 'تنظیمات', self::CAP, 'sheetsync-settings', ['SheetSync_Views', 'settings']);
    }

    public static function assets() {
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
        if (strpos($page, 'sheetsync') !== 0) {
            return;
        }
        wp_enqueue_style('sheetsync-admin', SHEETSYNC_URL . 'assets/admin.css', [], SHEETSYNC_VERSION . '.' . filemtime(SHEETSYNC_DIR . 'assets/admin.css'));
        wp_enqueue_script('sheetsync-admin', SHEETSYNC_URL . 'assets/admin.js', ['jquery'], SHEETSYNC_VERSION . '.' . filemtime(SHEETSYNC_DIR . 'assets/admin.js'), true);

        $data = ['ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('sheetsync_ajax')];
        if ($page === 'sheetsync-reconcile') {
            $terms = [];
            $taxes = [];
            foreach (SheetSync_Site::allowed() as $slug => $t) {
                $taxes[$slug] = ['label' => $t['label'], 'kind' => $t['kind']];
                $terms[$slug] = array_map(function ($x) {
                    return ['id' => $x['id'], 'path' => $x['path']];
                }, SheetSync_Site::terms($slug));
            }
            $data['terms'] = $terms;
            $data['taxes'] = $taxes;
        }
        wp_localize_script('sheetsync-admin', 'SheetSync', $data);
    }

    /* ---------- اعلان‌ها ---------- */

    public static function notice($type, $msg) {
        set_transient('sheetsync_notice_' . get_current_user_id(), ['type' => $type, 'msg' => $msg], 120);
    }

    public static function show_notice() {
        $key = 'sheetsync_notice_' . get_current_user_id();
        $n = get_transient($key);
        if ($n) {
            delete_transient($key);
            printf('<div class="ss-alert ss-alert-%s">%s</div>', esc_attr($n['type']), wp_kses_post($n['msg']));
        }
    }

    private static function guard($nonce_action) {
        if (!current_user_can(self::CAP)) {
            wp_die('دسترسی ندارید.');
        }
        check_admin_referer($nonce_action);
    }

    private static function back($default = 'sheetsync') {
        $page = isset($_REQUEST['back']) ? sanitize_key($_REQUEST['back']) : $default;
        if (!in_array($page, ['sheetsync', 'sheetsync-reconcile', 'sheetsync-settings'], true)) {
            $page = $default;
        }
        wp_safe_redirect(admin_url('admin.php?page=' . $page));
        exit;
    }

    /* ---------- هندلرها ---------- */

    public static function handle_fetch() {
        self::guard('sheetsync_fetch');
        $r = SheetSync_Syncer::fetch_to_staging();
        if (is_wp_error($r)) {
            self::notice('error', esc_html($r->get_error_message()));
        } else {
            $msg = sprintf('شیت دریافت شد: %d محصول جدید، %d تغییرکرده، %d بدون تغییر.', $r['new'], $r['changed'], $r['same']);
            if ($r['missing']) {
                $msg .= sprintf(' %d محصول دیگر در شیت نیست.', $r['missing']);
            }
            if ($r['dups']) {
                $msg .= sprintf(' <strong>%d ردیف با شناسه تکراری نادیده گرفته شد.</strong>', $r['dups']);
            }
            if ($r['skipped']) {
                $msg .= sprintf(' %d ردیف بدون شناسه نادیده گرفته شد.', $r['skipped']);
            }
            $type = 'success';
            if (!empty($r['stats']['unmapped'])) {
                $type = 'warning';
                $msg .= sprintf(' <strong>%d مقدار جدید در شیت هنوز نگاشت نشده</strong> — به «یکسان‌سازی داده‌ها» بروید.', $r['stats']['unmapped']);
            }
            self::notice($type, $msg);
        }
        self::back('sheetsync');
    }

    private static function save_general(array $p) {
        $p['csv_url']          = esc_url_raw(trim(wp_unslash($_POST['csv_url'] ?? '')));
        $p['header_rows']      = max(1, min(5, (int) ($_POST['header_rows'] ?? 2)));
        $p['price_multiplier'] = (float) ($_POST['price_multiplier'] ?? 1) ?: 1;
        $p['delimiter']        = SheetSync_Normalizer::clean(wp_unslash($_POST['delimiter'] ?? ',،'));
        $p['draft_values']     = sanitize_text_field(wp_unslash($_POST['draft_values'] ?? ''));
        $ps = sanitize_key($_POST['publish_status'] ?? 'publish');
        $p['publish_status']   = in_array($ps, ['publish', 'draft', 'pending'], true) ? $ps : 'publish';
        $p['decimal_stock']    = empty($_POST['decimal_stock']) ? 0 : 1;
        $p['price_suffix']     = sanitize_text_field(wp_unslash($_POST['price_suffix'] ?? ''));
        return $p;
    }

    /** ذخیره تنظیمات عمومی و ستون‌های اصلی (شناسه، نام، قیمت، ...). */
    public static function handle_save_settings() {
        self::guard('sheetsync_settings');
        $p = self::save_general(SheetSync_Profile::get());

        if (isset($_POST['core']) && $p['columns']) {
            $chosen = [];
            $used = [];
            foreach (SheetSync_Profile::CORE as $field) {
                $label = SheetSync_Normalizer::clean(wp_unslash($_POST['core'][$field] ?? ''));
                if ($label !== '' && !isset($used[$label])) {
                    $chosen[$field] = $label;
                    $used[$label] = true;
                }
            }
            foreach ($p['columns'] as &$c) {
                $field = array_search($c['label'], $chosen, true);
                if ($field !== false) {
                    $c['target'] = $field;
                    $c['dests'] = [];
                } elseif (in_array($c['target'], SheetSync_Profile::CORE, true)) {
                    $c['target'] = 'skip';
                }
            }
            unset($c);
        }
        SheetSync_Profile::save($p);

        if ($p['columns'] && SheetSync_Profile::label_for($p, 'sku') === '') {
            self::notice('warning', 'تنظیمات ذخیره شد، اما ستون «شناسه محصول» هنوز انتخاب نشده است؛ بدون آن همگام‌سازی ممکن نیست.');
        } else {
            self::notice('success', 'تنظیمات ذخیره شد.');
        }
        self::back('sheetsync-settings');
    }

    /** اتصال به شیت: خواندن ستون‌ها و مقادیر. نگاشت‌های قبلی حفظ می‌شود و هیچ مقصدی خودکار انتخاب نمی‌شود. */
    public static function handle_detect() {
        self::guard('sheetsync_settings');
        $p = SheetSync_Profile::get();
        if (isset($_POST['csv_url'])) {
            $p = self::save_general($p);
            SheetSync_Profile::save($p);
        }

        $res = SheetSync_Fetcher::fetch($p);
        if (is_wp_error($res)) {
            self::notice('error', esc_html($res->get_error_message()));
            self::back('sheetsync-settings');
        }

        $old = [];
        foreach ($p['columns'] as $c) {
            $old[$c['label']] = $c;
        }
        $cols = [];
        $new = 0;
        foreach ($res['columns'] as $c) {
            if (isset($old[$c['label']])) {
                $keep = $old[$c['label']];
                $keep['group'] = $c['group'];
                $cols[] = $keep;
                continue;
            }
            $new++;
            $cols[] = [
                'label'  => $c['label'],
                'group'  => $c['group'],
                'target' => SheetSync_Profile::detect_target($c['label'], $c['group']),
                'dests'  => [],
            ];
        }
        $p['columns'] = $cols;
        SheetSync_Profile::save($p);
        update_option(SheetSync_Profile::SNAP, SheetSync_Syncer::build_snapshot($res['columns'], $res['rows'], $p), false);

        $msg = sprintf('اتصال برقرار شد: %d ردیف و %d ستون خوانده شد.', count($res['rows']), count($cols));
        if ($old && $new) {
            $msg .= sprintf(' %d ستون جدید پیدا شد.', $new);
        }
        if ((isset($_REQUEST['back']) ? sanitize_key($_REQUEST['back']) : '') === 'sheetsync-settings') {
            $msg .= ' ستون‌های اصلی را بررسی و ذخیره کنید، سپس به «یکسان‌سازی داده‌ها» بروید.';
        }
        self::notice('success', $msg);
        self::back('sheetsync-reconcile');
    }

    /** تأیید ادمین: نگاشت انجام شده و آپدیت محصولات فعال شود. */
    public static function handle_confirm() {
        self::guard('sheetsync_confirm');
        $p = SheetSync_Profile::get();
        if (SheetSync_Profile::label_for($p, 'sku') === '') {
            self::notice('error', 'ابتدا در تنظیمات ستون «شناسه محصول» را انتخاب کنید.');
            self::back('sheetsync-settings');
        }
        $p['mapping_confirmed'] = 1;
        SheetSync_Profile::save($p);
        self::notice('success', 'نگاشت تأیید شد. حالا می‌توانید در «محصولات» آپدیت را انجام دهید.');
        self::back('sheetsync-reconcile');
    }

    /* ---------- AJAX ---------- */

    private static function ajax_guard() {
        check_ajax_referer('sheetsync_ajax', 'nonce');
        if (!current_user_can(self::CAP)) {
            wp_send_json_error(['msg' => 'دسترسی ندارید.'], 403);
        }
    }

    public static function ajax_apply() {
        self::ajax_guard();
        if (function_exists('set_time_limit')) {
            @set_time_limit(120);
        }
        $ids = array_map('intval', (array) ($_POST['ids'] ?? []));
        $results = [];
        foreach ($ids as $id) {
            $results[] = SheetSync_Syncer::apply($id);
        }
        wp_send_json_success(['results' => $results]);
    }

    /** ذخیره نگاشت یک ستون (مقصدها و معادل مقادیر). */
    public static function ajax_save_column() {
        self::ajax_guard();
        $d = json_decode(wp_unslash($_POST['payload'] ?? ''), true);
        if (!is_array($d) || empty($d['label'])) {
            wp_send_json_error(['msg' => 'اطلاعات نامعتبر است.']);
        }
        $p = SheetSync_Profile::get();
        $label = SheetSync_Normalizer::clean($d['label']);
        $idx = null;
        foreach ($p['columns'] as $i => $c) {
            if ($c['label'] === $label) {
                $idx = $i;
                break;
            }
        }
        if ($idx === null) {
            wp_send_json_error(['msg' => 'ستون پیدا نشد؛ دوباره اتصال به شیت را بزنید.']);
        }

        if (empty($d['enabled'])) {
            // خاموش کردن ستون: مقصدها و نگاشت‌ها نگه داشته می‌شود تا با روشن کردن دوباره برگردد
            $p['columns'][$idx]['target'] = 'skip';
            SheetSync_Profile::save($p);
            wp_send_json_success(['msg' => 'این ستون نادیده گرفته می‌شود.', 'mapped' => 0, 'total' => 0]);
        }

        $allowed = array_keys(SheetSync_Site::allowed());
        $col = SheetSync_Profile::sanitize_columns([[
            'label' => $label, 'group' => $p['columns'][$idx]['group'], 'target' => 'terms',
            'dests' => (array) ($d['dests'] ?? []),
        ]], $allowed)[0];
        $p['columns'][$idx] = $col;

        $vals = [];
        foreach ((array) ($d['values'] ?? []) as $v) {
            $hash = (string) ($v['hash'] ?? '');
            $vals[$hash] = ['label' => $v['label'] ?? '', 'to' => (array) ($v['to'] ?? [])];
        }
        $vm = SheetSync_Profile::sanitize_value_map([$idx => $vals], [$idx => $col]);
        if (!empty($vm[$label])) {
            $p['value_map'][$label] = $vm[$label];
        } else {
            unset($p['value_map'][$label]);
        }
        SheetSync_Profile::save($p);

        $snap = SheetSync_Profile::snapshot();
        $values = $snap['columns'][$label]['values'] ?? [];
        $mapped = 0;
        foreach ($values as $h => $v) {
            if (!empty($p['value_map'][$label][$h]['to'])) {
                $mapped++;
            }
        }
        wp_send_json_success([
            'msg' => $col['dests'] ? 'ذخیره شد.' : 'ذخیره شد؛ برای نگاشت مقادیر یک مقصد انتخاب کنید.',
            'mapped' => $mapped,
            'total' => count($values),
        ]);
    }
}
