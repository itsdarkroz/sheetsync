<?php
/**
 * Plugin Name: SheetSync – همگام‌سازی محصولات با گوگل شیت
 * Description: دریافت محصولات، دسته‌بندی‌ها و ویژگی‌ها از گوگل شیت و ساخت/آپدیت آن‌ها در ووکامرس، با تأیید دستی ادمین برای هر محصول.
 * Version: 0.1.0
 * Requires PHP: 7.4
 * Text Domain: sheetsync
 */
defined('ABSPATH') || exit;

define('SHEETSYNC_VERSION', '0.1.0');
define('SHEETSYNC_FILE', __FILE__);
define('SHEETSYNC_DIR', plugin_dir_path(__FILE__));
define('SHEETSYNC_URL', plugin_dir_url(__FILE__));

require_once SHEETSYNC_DIR . 'includes/class-normalizer.php';
require_once SHEETSYNC_DIR . 'includes/class-profile.php';
require_once SHEETSYNC_DIR . 'includes/class-site.php';
require_once SHEETSYNC_DIR . 'includes/class-fetcher.php';
require_once SHEETSYNC_DIR . 'includes/class-repo.php';
require_once SHEETSYNC_DIR . 'includes/class-syncer.php';
require_once SHEETSYNC_DIR . 'admin/class-admin.php';
require_once SHEETSYNC_DIR . 'admin/class-views.php';

register_activation_hook(__FILE__, ['SheetSync_Repo', 'install']);

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', SHEETSYNC_FILE, true);
    }
});

add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>افزونه SheetSync برای کار کردن به ووکامرس نیاز دارد.</p></div>';
        });
        return;
    }
    SheetSync_Plugin::init();
});

class SheetSync_Plugin {

    public static function init() {
        $p = SheetSync_Profile::get();

        // ارتقای ساختار جدول (ستون جدید) بدون نیاز به غیرفعال/فعال کردن افزونه
        if (is_admin() && get_option('sheetsync_db') !== '2') {
            SheetSync_Repo::install();
            update_option('sheetsync_db', '2');
        }

        // موجودی اعشاری (مثلاً ۲.۵ متر)
        if (!empty($p['decimal_stock'])) {
            add_filter('woocommerce_stock_amount', 'floatval');
        }

        // پسوند قیمت، مثلاً «هر متر»
        if (!empty($p['price_suffix'])) {
            add_filter('woocommerce_get_price_html', function ($html) use ($p) {
                return $html === '' ? $html : $html . ' <span class="sheetsync-suffix">' . esc_html($p['price_suffix']) . '</span>';
            }, 10, 1);
        }

        if (is_admin()) {
            SheetSync_Admin::init();
        }
    }
}
