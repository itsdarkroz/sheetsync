<?php
defined('ABSPATH') || exit;

/** تنظیمات، نگاشت ستون‌ها و نگاشت مقادیر. */
class SheetSync_Profile {

    const OPT  = 'sheetsync_profile';
    const SNAP = 'sheetsync_snapshot';

    const CORE = ['sku', 'name', 'regular_price', 'sale_price', 'stock', 'status'];

    const TARGETS = [
        'skip'          => 'نادیده گرفتن',
        'sku'           => 'شناسه محصول (SKU)',
        'name'          => 'نام محصول',
        'regular_price' => 'قیمت',
        'sale_price'    => 'قیمت تخفیفی',
        'stock'         => 'موجودی',
        'status'        => 'وضعیت آپدیت',
        'terms'         => 'مقادیر ← دسته‌بندی / ویژگی / برچسب سایت',
    ];

    public static function defaults() {
        return [
            'csv_url'           => '',
            'header_rows'       => 2,
            'price_multiplier'  => 1,
            'delimiter'         => ',،',
            'decimal_stock'     => 1,
            'price_suffix'      => '',
            'draft_values'      => 'آپدیت فروشگاه',
            'publish_status'    => 'publish',
            'columns'           => [],   // [{label, group, target, dests[]}]
            'value_map'         => [],   // [label => [md5(key) => {label, to:[{tax,id}]}]]
            'mapping_confirmed' => 0,
        ];
    }

    public static function get() {
        $saved = get_option(self::OPT, []);
        $p = array_merge(self::defaults(), is_array($saved) ? $saved : []);
        $cols = [];
        foreach ((array) $p['columns'] as $c) {
            if (empty($c['label'])) {
                continue;
            }
            $t = $c['target'] ?? 'skip';
            // سازگاری با نسخه آزمایشی قبلی که تکسونومی/ویژگی خودش را می‌ساخت
            if (in_array($t, ['taxonomy', 'attribute'], true)) {
                $t = 'terms';
            }
            if (!isset(self::TARGETS[$t])) {
                $t = 'skip';
            }
            $cols[] = [
                'label'  => $c['label'],
                'group'  => $c['group'] ?? '',
                'target' => $t,
                'dests'  => array_values(array_filter((array) ($c['dests'] ?? []))),
            ];
        }
        $p['columns'] = $cols;
        if (!is_array($p['value_map'])) {
            $p['value_map'] = [];
        }
        return $p;
    }

    public static function save(array $p) {
        update_option(self::OPT, $p, false);
    }

    public static function snapshot() {
        $s = get_option(self::SNAP, []);
        return is_array($s) ? $s : [];
    }

    public static function label_for(array $p, $target) {
        foreach ($p['columns'] as $c) {
            if ($c['target'] === $target) {
                return $c['label'];
            }
        }
        return '';
    }

    public static function config_hash(array $p) {
        return md5(wp_json_encode([$p['columns'], $p['value_map'], $p['price_multiplier'], $p['delimiter'], $p['draft_values']]));
    }

    /** حدس نوع ستون: فقط فیلدهای اصلی (قیمت، موجودی، ...) و گروه‌های «دسته‌بندی/ویژگی». مقصد هیچ ستونی خودکار تعیین نمی‌شود. */
    public static function detect_target($label, $group) {
        $l = SheetSync_Normalizer::key($label);
        $g = SheetSync_Normalizer::key($group);
        $has = function ($needle) use ($l) {
            return strpos($l, SheetSync_Normalizer::key($needle)) !== false;
        };
        if ($has('شناسه') || $has('کدمحصول') || $l === 'sku') return 'sku';
        if ($has('تخفیف'))                                  return 'sale_price';
        if ($has('قیمت'))                                   return 'regular_price';
        if ($has('متراژ') || $has('موجودی'))                 return 'stock';
        if ($has('وضعیت'))                                  return 'status';
        if ($has('لینک'))                                   return 'skip';
        if ($has('ناممحصول') || $l === 'نام')               return 'name';
        if ($g !== '' && (strpos($g, SheetSync_Normalizer::key('دسته')) !== false || strpos($g, SheetSync_Normalizer::key('ویژگی')) !== false)) {
            return 'terms';
        }
        return 'skip';
    }

    public static function sanitize_columns($posted, array $allowed_tax) {
        $out = [];
        foreach ((array) $posted as $c) {
            $label = isset($c['label']) ? SheetSync_Normalizer::clean($c['label']) : '';
            if ($label === '') {
                continue;
            }
            $target = isset($c['target']) ? sanitize_key($c['target']) : 'skip';
            if (!isset(self::TARGETS[$target])) {
                $target = 'skip';
            }
            $dests = [];
            if ($target === 'terms') {
                foreach ((array) ($c['dests'] ?? []) as $d) {
                    $d = sanitize_key($d);
                    if (in_array($d, $allowed_tax, true)) {
                        $dests[$d] = $d;
                    }
                }
            }
            $out[] = [
                'label'  => $label,
                'group'  => isset($c['group']) ? SheetSync_Normalizer::clean($c['group']) : '',
                'target' => $target,
                'dests'  => array_values($dests),
            ];
        }
        return $out;
    }

    /** فقط نگاشت‌هایی که ادمین صراحتاً انتخاب کرده و ترمشان در سایت موجود است ذخیره می‌شود. */
    public static function sanitize_value_map($posted, array $columns) {
        $out = [];
        foreach ((array) $posted as $i => $vals) {
            $col = $columns[(int) $i] ?? null;
            if (!$col || $col['target'] !== 'terms' || !$col['dests']) {
                continue;
            }
            foreach ((array) $vals as $hash => $entry) {
                if (!preg_match('/^[a-f0-9]{32}$/', (string) $hash)) {
                    continue;
                }
                $to = [];
                foreach ((array) ($entry['to'] ?? []) as $pair) {
                    $parts = explode('|', (string) $pair);
                    if (count($parts) !== 2) {
                        continue;
                    }
                    $tax = sanitize_key($parts[0]);
                    $id = (int) $parts[1];
                    if (!in_array($tax, $col['dests'], true) || !$id) {
                        continue;
                    }
                    $term = get_term($id, $tax);
                    if (!$term || is_wp_error($term)) {
                        continue;
                    }
                    $to[$tax . '|' . $id] = ['tax' => $tax, 'id' => $id];
                }
                if ($to) {
                    $out[$col['label']][$hash] = [
                        'label' => SheetSync_Normalizer::clean($entry['label'] ?? ''),
                        'to'    => array_values($to),
                    ];
                }
            }
        }
        return $out;
    }

    /** آمار مقادیر جدید (نگاشت‌نشده) و حذف‌شده از شیت. */
    public static function stats(array $p, array $snap) {
        $s = ['unmapped' => 0, 'stale' => 0, 'no_dest' => 0];
        foreach ($p['columns'] as $c) {
            if ($c['target'] !== 'terms') {
                continue;
            }
            if (!$c['dests']) {
                $s['no_dest']++;
                continue;
            }
            $vals = $snap['columns'][$c['label']]['values'] ?? [];
            $map = $p['value_map'][$c['label']] ?? [];
            foreach ($vals as $h => $v) {
                if (empty($map[$h]['to'])) {
                    $s['unmapped']++;
                }
            }
            if ($vals) {
                foreach ($map as $h => $e) {
                    if (!isset($vals[$h])) {
                        $s['stale']++;
                    }
                }
            }
        }
        return $s;
    }

    /** تعداد نگاشت‌هایی که مقصدشان از سایت حذف شده است. */
    public static function broken_count(array $p) {
        $n = 0;
        foreach ($p['value_map'] as $vals) {
            foreach ($vals as $e) {
                foreach ($e['to'] as $to) {
                    if (!SheetSync_Site::term_exists($to['tax'], $to['id'])) {
                        $n++;
                        break;
                    }
                }
            }
        }
        return $n;
    }
}
