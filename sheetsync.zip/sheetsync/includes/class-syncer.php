<?php
defined('ABSPATH') || exit;

class SheetSync_Syncer {

    /** مرحله ۱: دریافت شیت، ذخیره در جدول واسط و به‌روزرسانی فهرست مقادیر شیت. به محصولات دست نمی‌زند. */
    public static function fetch_to_staging() {
        $p = SheetSync_Profile::get();
        $sku_label = SheetSync_Profile::label_for($p, 'sku');
        if ($sku_label === '') {
            return new WP_Error('ss_map', 'ستونی به‌عنوان «شناسه محصول» تعیین نشده است. در تنظیمات، ستون‌ها را تشخیص دهید و نگاشت را ذخیره کنید.');
        }
        $res = SheetSync_Fetcher::fetch($p);
        if (is_wp_error($res)) {
            return $res;
        }

        $snap = self::build_snapshot($res['columns'], $res['rows'], $p);
        update_option(SheetSync_Profile::SNAP, $snap, false);

        $name_label   = SheetSync_Profile::label_for($p, 'name');
        $status_label = SheetSync_Profile::label_for($p, 'status');
        $cfg = SheetSync_Profile::config_hash($p);

        $count = ['new' => 0, 'changed' => 0, 'same' => 0, 'skipped' => 0, 'dups' => 0, 'missing' => 0];
        $seen = [];
        foreach ($res['rows'] as $row) {
            $sku = SheetSync_Normalizer::clean($row[$sku_label] ?? '');
            if ($sku === '') {
                $count['skipped']++;
                continue;
            }
            $k = strtolower($sku);
            if (isset($seen[$k])) {
                $count['dups']++;
                continue;
            }
            $seen[$k] = $sku;
            $hash = md5(wp_json_encode($row, JSON_UNESCAPED_UNICODE) . $cfg);
            $title = $name_label !== '' ? SheetSync_Normalizer::clean($row[$name_label] ?? '') : '';
            $status = $status_label !== '' ? SheetSync_Normalizer::clean($row[$status_label] ?? '') : '';
            $count[SheetSync_Repo::upsert($sku, $row, $hash, mb_substr($title, 0, 250), mb_substr($status, 0, 90))]++;
        }
        $count['missing'] = SheetSync_Repo::mark_missing(array_values($seen));
        $count['stats'] = SheetSync_Profile::stats($p, $snap);
        update_option('sheetsync_last_fetch', array_merge($count, ['time' => current_time('mysql')]), false);
        return $count;
    }

    /** فهرست مقادیر یکتای هر ستون شیت (به‌جز فیلدهای اصلی مثل قیمت) با تعداد محصولاتی که دارندش. */
    public static function build_snapshot(array $columns, array $rows, array $p) {
        $snap = ['time' => current_time('mysql'), 'rows' => count($rows), 'cols' => count($columns), 'columns' => []];
        foreach ($columns as $col) {
            $label = $col['label'];
            if (in_array(SheetSync_Profile::detect_target($label, $col['group']), SheetSync_Profile::CORE, true)) {
                continue;
            }
            $vals = [];
            foreach ($rows as $row) {
                foreach (SheetSync_Normalizer::split($row[$label] ?? '', $p['delimiter']) as $v) {
                    $h = md5(SheetSync_Normalizer::key($v));
                    if (!isset($vals[$h])) {
                        if (count($vals) >= 400) {
                            continue;
                        }
                        $vals[$h] = ['label' => $v, 'count' => 0];
                    }
                    $vals[$h]['count']++;
                }
            }
            $snap['columns'][$label] = ['group' => $col['group'], 'values' => $vals];
        }
        return $snap;
    }

    /** مرحله ۲: ساخت/آپدیت محصول برای یک ردیف staging. */
    public static function apply($id) {
        $row = SheetSync_Repo::get($id);
        if (!$row) {
            return ['ok' => false, 'msg' => 'ردیف پیدا نشد.'];
        }
        $p = SheetSync_Profile::get();
        if (empty($p['mapping_confirmed'])) {
            return ['ok' => false, 'sku' => $row->sku, 'msg' => 'ابتدا در «تنظیمات و نگاشت» ستون‌ها و مقادیر را نگاشت و ذخیره کنید.'];
        }
        try {
            $data = json_decode($row->data, true);
            $r = self::apply_data($row->sku, is_array($data) ? $data : [], $p);
            SheetSync_Repo::set_result($id, 'synced', $r['product_id'], null, $r['notes']);
            return ['ok' => true, 'sku' => $row->sku, 'product_id' => $r['product_id'], 'notes' => $r['notes']];
        } catch (Throwable $e) {
            SheetSync_Repo::set_result($id, 'error', (int) $row->product_id, $e->getMessage());
            return ['ok' => false, 'sku' => $row->sku, 'msg' => $e->getMessage()];
        }
    }

    private static function price($n, $mult) {
        $v = (float) $n * (float) $mult;
        return wc_format_decimal(number_format($v, 2, '.', ''), false, true);
    }

    private static function apply_data($sku, array $data, array $p) {
        $notes = [];
        $product_id = wc_get_product_id_by_sku($sku);
        $product = $product_id ? wc_get_product($product_id) : new WC_Product_Simple();
        if (!$product) {
            throw new Exception('محصول پیدا نشد.');
        }
        $is_new = !$product->get_id();
        if ($is_new) {
            $product->set_sku($sku);
        }

        $name = '';
        $status_raw = '';
        $term_sets = [];   // [taxonomy => [id => id]]

        foreach ($p['columns'] as $c) {
            $t = $c['target'];
            if ($t === 'skip' || $t === 'sku') {
                continue;
            }
            $raw = SheetSync_Normalizer::clean($data[$c['label']] ?? '');
            if ($raw === '') {
                continue; // سلول خالی: هیچ چیزی تغییر نمی‌کند
            }
            switch ($t) {
                case 'name':
                    $name = $raw;
                    break;
                case 'status':
                    $status_raw = $raw;
                    break;
                case 'regular_price':
                case 'sale_price':
                    $n = SheetSync_Normalizer::number($raw);
                    if ($n !== '') {
                        $t === 'regular_price'
                            ? $product->set_regular_price(self::price($n, $p['price_multiplier']))
                            : $product->set_sale_price(self::price($n, $p['price_multiplier']));
                    }
                    break;
                case 'stock':
                    $n = SheetSync_Normalizer::number($raw);
                    if ($n !== '') {
                        $product->set_manage_stock(true);
                        $product->set_stock_quantity((float) $n);
                        $product->set_stock_status((float) $n > 0 ? 'instock' : 'outofstock');
                    }
                    break;
                case 'terms':
                    if (!$c['dests']) {
                        $notes[] = 'ستون «' . $c['label'] . '» مقصدی ندارد و اعمال نشد.';
                        break;
                    }
                    foreach (SheetSync_Normalizer::split($raw, $p['delimiter']) as $v) {
                        $entry = $p['value_map'][$c['label']][md5(SheetSync_Normalizer::key($v))] ?? null;
                        if (!$entry || empty($entry['to'])) {
                            $notes[] = 'مقدار «' . $v . '» (ستون «' . $c['label'] . '») نگاشت نشده و اعمال نشد.';
                            continue;
                        }
                        foreach ($entry['to'] as $to) {
                            if (!SheetSync_Site::term_exists($to['tax'], $to['id'])) {
                                $notes[] = 'مقدار «' . $v . '»: مقصد نگاشت‌شده در سایت وجود ندارد (حذف شده؟).';
                                continue;
                            }
                            $term_sets[$to['tax']][(int) $to['id']] = (int) $to['id'];
                        }
                    }
                    break;
            }
        }

        // قیمت تخفیفی باید کمتر از قیمت اصلی باشد
        $sale = $product->get_sale_price();
        if ($sale !== '' && $product->get_regular_price() !== '' && (float) $sale >= (float) $product->get_regular_price()) {
            $product->set_sale_price('');
            $notes[] = 'قیمت تخفیفی کمتر از قیمت اصلی نبود و اعمال نشد.';
        }

        // وضعیت: ردیف‌های «آپدیت فروشگاه» → پیش‌نویس با کد محصول به‌جای نام
        $draft_keys = array_filter(array_map([SheetSync_Normalizer::class, 'key'], explode(',', $p['draft_values'])));
        $is_draft = $status_raw !== '' && in_array(SheetSync_Normalizer::key($status_raw), $draft_keys, true);
        if ($is_draft) {
            $product->set_name($sku);
            $product->set_status('draft');
        } else {
            if ($name !== '') {
                $product->set_name($name);
            } elseif ($is_new) {
                $product->set_name($sku);
            }
            if ($status_raw !== '' || $is_new) {
                $product->set_status($p['publish_status']);
            }
        }

        // ترم‌های ویژگی‌های موجود (pa_*) در تب «ویژگی‌ها»ی محصول هم ثبت می‌شوند
        $attrs = $product->get_attributes();
        $attrs_changed = false;
        foreach ($term_sets as $tax => $ids) {
            if (strpos($tax, 'pa_') !== 0 || !wc_attribute_taxonomy_id_by_name($tax)) {
                continue;
            }
            $attr = new WC_Product_Attribute();
            $attr->set_id(wc_attribute_taxonomy_id_by_name($tax));
            $attr->set_name($tax);
            $attr->set_options(array_values($ids));
            $attr->set_position(count($attrs));
            $attr->set_visible(true);
            $attr->set_variation(false);
            $attrs[$tax] = $attr;
            $attrs_changed = true;
        }
        if ($attrs_changed) {
            $product->set_attributes($attrs);
        }

        $pid = $product->save();
        foreach ($term_sets as $tax => $ids) {
            wp_set_object_terms($pid, array_values($ids), $tax);
        }
        return ['product_id' => $pid, 'notes' => array_values(array_unique($notes))];
    }
}
