<?php
defined('ABSPATH') || exit;

/** جدول واسط (staging): هر ردیف شیت یک رکورد. */
class SheetSync_Repo {

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . 'sheetsync_rows';
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  sku varchar(100) NOT NULL,
  row_hash char(32) NOT NULL,
  data longtext NOT NULL,
  title varchar(255) NOT NULL DEFAULT '',
  sheet_status varchar(100) NOT NULL DEFAULT '',
  product_id bigint(20) unsigned NOT NULL DEFAULT 0,
  state varchar(20) NOT NULL DEFAULT 'new',
  error text NULL,
  notes text NULL,
  last_synced datetime NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY sku (sku),
  KEY state (state)
) {$charset};");
    }

    /** @return string new|changed|same */
    public static function upsert($sku, array $data, $hash, $title, $sheet_status) {
        global $wpdb;
        $t = self::table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT id, row_hash, state, product_id FROM {$t} WHERE sku = %s", $sku));
        $json = wp_json_encode($data, JSON_UNESCAPED_UNICODE);
        $now = current_time('mysql');

        if (!$row) {
            $wpdb->insert($t, [
                'sku' => $sku, 'row_hash' => $hash, 'data' => $json, 'title' => $title,
                'sheet_status' => $sheet_status, 'state' => 'new', 'updated_at' => $now,
            ]);
            return 'new';
        }
        if ($row->row_hash !== $hash) {
            $wpdb->update($t, [
                'row_hash' => $hash, 'data' => $json, 'title' => $title, 'sheet_status' => $sheet_status,
                'state' => $row->product_id ? 'changed' : 'new', 'error' => null, 'notes' => null, 'updated_at' => $now,
            ], ['id' => $row->id]);
            return 'changed';
        }
        if ($row->state === 'missing') {
            $wpdb->update($t, ['state' => $row->product_id ? 'synced' : 'new'], ['id' => $row->id]);
        }
        return 'same';
    }

    public static function mark_missing(array $present_skus) {
        global $wpdb;
        $t = self::table();
        $all = $wpdb->get_results("SELECT id, sku FROM {$t} WHERE state <> 'missing'");
        $present = array_flip(array_map('strtolower', $present_skus));
        $n = 0;
        foreach ($all as $r) {
            if (!isset($present[strtolower($r->sku)])) {
                $wpdb->update($t, ['state' => 'missing'], ['id' => $r->id]);
                $n++;
            }
        }
        return $n;
    }

    public static function get($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table() . ' WHERE id = %d', $id));
    }

    public static function set_result($id, $state, $product_id, $error = null, $notes = null) {
        global $wpdb;
        $wpdb->update(self::table(), [
            'state' => $state, 'product_id' => (int) $product_id, 'error' => $error,
            'notes' => $notes ? implode("\n", array_slice((array) $notes, 0, 30)) : null,
            'last_synced' => $state === 'synced' ? current_time('mysql') : null,
        ], ['id' => $id]);
    }

    private static function where($state, $search) {
        global $wpdb;
        $w = [];
        if ($state !== '') {
            $w[] = $wpdb->prepare('state = %s', $state);
        }
        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $w[] = $wpdb->prepare('(sku LIKE %s OR title LIKE %s)', $like, $like);
        }
        return $w ? 'WHERE ' . implode(' AND ', $w) : '';
    }

    public static function query($state, $paged, $per_page, $search = '') {
        global $wpdb;
        $t = self::table();
        $where = self::where($state, $search);
        $offset = max(0, ($paged - 1) * $per_page);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} {$where} ORDER BY id ASC LIMIT %d OFFSET %d", $per_page, $offset));
    }

    public static function count($state = '', $search = '') {
        global $wpdb;
        $t = self::table();
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} " . self::where($state, $search));
    }

    public static function counts() {
        global $wpdb;
        $out = [];
        foreach ($wpdb->get_results('SELECT state, COUNT(*) c FROM ' . self::table() . ' GROUP BY state') as $r) {
            $out[$r->state] = (int) $r->c;
        }
        return $out;
    }
}
