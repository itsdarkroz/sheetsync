<?php
defined('ABSPATH') || exit;

/** دریافت و پارس CSV گوگل شیت. */
class SheetSync_Fetcher {

    /** لینک عادی شیت را به لینک خروجی CSV تبدیل می‌کند. */
    public static function normalize_url($url) {
        $url = trim($url);
        if ($url === '' || stripos($url, 'output=csv') !== false || stripos($url, 'format=csv') !== false) {
            return $url;
        }
        if (preg_match('#/spreadsheets/d/([a-zA-Z0-9_-]+)#', $url, $m) && stripos($url, '/d/e/') === false) {
            $gid = preg_match('/[#&?]gid=(\d+)/', $url, $g) ? $g[1] : '0';
            return 'https://docs.google.com/spreadsheets/d/' . $m[1] . '/export?format=csv&gid=' . $gid;
        }
        return $url;
    }

    /**
     * @return array|WP_Error ['columns' => [['label','group'],...], 'rows' => [[label => value],...]]
     */
    public static function fetch(array $p) {
        $url = self::normalize_url($p['csv_url']);
        if ($url === '') {
            return new WP_Error('ss_url', 'آدرس گوگل شیت در تنظیمات وارد نشده است.');
        }
        $res = wp_remote_get($url, ['timeout' => 30, 'redirection' => 5]);
        if (is_wp_error($res)) {
            return new WP_Error('ss_http', 'خطا در دریافت شیت: ' . $res->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code !== 200) {
            return new WP_Error('ss_http', 'گوگل پاسخ ' . $code . ' داد. مطمئن شوید شیت منتشر یا برای «هر کسی که لینک دارد» قابل مشاهده است.');
        }
        $body = preg_replace('/^\xEF\xBB\xBF/', '', $body);
        if (stripos(ltrim($body), '<') === 0) {
            return new WP_Error('ss_private', 'شیت عمومی نیست (به‌جای CSV صفحه HTML برگشت). شیت را «Publish to web» کنید.');
        }

        $all = [];
        $h = fopen('php://temp', 'r+');
        fwrite($h, $body);
        rewind($h);
        while (($row = fgetcsv($h, 0, ',', '"', '')) !== false) {
            $all[] = $row;
        }
        fclose($h);

        $hdr = max(1, (int) $p['header_rows']);
        if (count($all) < $hdr) {
            return new WP_Error('ss_empty', 'شیت خالی است یا تعداد ردیف‌های هدر بیشتر از ردیف‌های شیت است.');
        }

        $label_row = $all[$hdr - 1];
        $group_row = $hdr >= 2 ? $all[$hdr - 2] : [];

        // ردیف گروه‌بندی (merged) → مقدار هر سلول خالی از سلول قبلی پر می‌شود
        $columns = [];
        $seen = [];
        $last_group = '';
        foreach ($label_row as $i => $raw_label) {
            $g = SheetSync_Normalizer::clean($group_row[$i] ?? '');
            if ($g !== '') {
                $last_group = $g;
            }
            $label = SheetSync_Normalizer::clean($raw_label);
            if ($label === '') {
                continue;
            }
            $base = $label;
            $n = 1;
            while (isset($seen[$label])) {
                $label = $base . ' (' . (++$n) . ')';
            }
            $seen[$label] = true;
            $columns[$i] = ['label' => $label, 'group' => $last_group];
        }

        $rows = [];
        for ($r = $hdr; $r < count($all); $r++) {
            $assoc = [];
            $empty = true;
            foreach ($columns as $i => $col) {
                $v = trim((string) ($all[$r][$i] ?? ''));
                if ($v !== '') {
                    $empty = false;
                }
                $assoc[$col['label']] = $v;
            }
            if (!$empty) {
                $rows[] = $assoc;
            }
        }

        return ['columns' => array_values($columns), 'rows' => $rows];
    }
}
