<?php
defined('ABSPATH') || exit;

/** نرمال‌سازی متن فارسی: ی/ک عربی، نیم‌فاصله، فاصله‌های اضافه، ارقام. */
class SheetSync_Normalizer {

    const INVISIBLE = '\x{200C}\x{200B}\x{200E}\x{200F}\x{FEFF}';

    /** پاک‌سازی برای نمایش (نیم‌فاصله‌های داخل کلمه حفظ می‌شود). */
    public static function clean($s) {
        $s = (string) $s;
        $s = strtr($s, ['ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک', 'ـ' => '']);
        $s = preg_replace('/[\x{064B}-\x{065F}]/u', '', $s);
        $s = preg_replace('/[\x{00A0}\x{2009}\x{200A}\x{202F}]/u', ' ', $s);
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[' . self::INVISIBLE . '\s]+|[' . self::INVISIBLE . '\s]+$/u', '', $s);
        return $s === null ? '' : $s;
    }

    /** کلید مقایسه: «سورمه ای» و «سورمه‌ای» یک کلید دارند. */
    public static function key($s) {
        $s = self::clean($s);
        $s = preg_replace('/[' . self::INVISIBLE . '\s]+/u', '', $s);
        return strtolower((string) $s);
    }

    public static function digits($s) {
        return strtr((string) $s, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
            '٫' => '.', '٬' => '',
        ]);
    }

    /** عدد تمیز (رشته) یا رشته خالی اگر عدد نبود. */
    public static function number($s) {
        $s = self::digits(self::clean($s));
        $s = str_replace([',', '،', ' '], '', $s);
        return is_numeric($s) ? $s : '';
    }

    /** جدا کردن سلول چندمقداری؛ مقادیر تکراری (بعد از نرمال‌سازی) حذف می‌شوند. */
    public static function split($s, $delims) {
        $s = self::clean($s);
        if ($s === '') {
            return [];
        }
        $parts = $delims === '' ? [$s] : preg_split('/[' . preg_quote($delims, '/') . ']/u', $s);
        $out = [];
        foreach ($parts as $part) {
            $part = self::clean($part);
            if ($part === '') {
                continue;
            }
            $k = self::key($part);
            if (!isset($out[$k])) {
                $out[$k] = $part;
            }
        }
        return array_values($out);
    }
}
