<?php
defined('ABSPATH') || exit;

/** تشخیص تعاریف موجود در سایت (دسته‌بندی‌ها، برچسب‌ها، ویژگی‌ها). این کلاس هیچ چیزی نمی‌سازد. */
class SheetSync_Site {

    const EXCLUDE = ['product_type', 'product_visibility', 'product_shipping_class'];

    public static function taxonomies() {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        $cache = [];
        foreach (get_object_taxonomies('product', 'objects') as $slug => $tax) {
            if (in_array($slug, self::EXCLUDE, true)) {
                continue;
            }
            $kind = 'other';
            if ($slug === 'product_cat') {
                $kind = 'category';
            } elseif ($slug === 'product_tag') {
                $kind = 'tag';
            } elseif (strpos($slug, 'pa_') === 0) {
                $kind = 'attribute';
            }
            $cache[$slug] = [
                'slug'         => $slug,
                'label'        => $tax->label ?: $slug,
                'kind'         => $kind,
                'hierarchical' => (bool) $tax->hierarchical,
                // ویژگی‌هایی که نسخه آزمایشی قبلی همین افزونه ساخته بود
                'legacy'       => (bool) preg_match('/^pa_ss[0-9a-f]{8}$/', $slug) || (bool) preg_match('/^ss[0-9a-f]{8}$/', $slug),
            ];
        }
        return $cache;
    }

    /** تکسونومی‌هایی که می‌شود به آن‌ها نگاشت داد. */
    public static function allowed() {
        return array_filter(self::taxonomies(), function ($t) {
            return !$t['legacy'];
        });
    }

    public static function kind_label($kind) {
        $m = ['category' => 'دسته‌بندی محصول', 'tag' => 'برچسب', 'attribute' => 'ویژگی', 'other' => 'سایر'];
        return $m[$kind] ?? $kind;
    }

    /**
     * همه ترم‌های یک تکسونومی با ساختار درختی (دسته، زیردسته، زیرِ زیردسته...).
     * @return array [['id','name','path','depth','count'], ...]
     */
    public static function terms($taxonomy) {
        static $cache = [];
        if (isset($cache[$taxonomy])) {
            return $cache[$taxonomy];
        }
        $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false, 'orderby' => 'name']);
        if (is_wp_error($terms) || !is_array($terms)) {
            return $cache[$taxonomy] = [];
        }
        $by = [];
        $ids = [];
        foreach ($terms as $t) {
            $ids[$t->term_id] = true;
        }
        foreach ($terms as $t) {
            $parent = ($t->parent && isset($ids[$t->parent])) ? (int) $t->parent : 0;
            $by[$parent][] = $t;
        }
        $list = [];
        $walk = function ($parent, $path, $depth) use (&$walk, &$by, &$list) {
            foreach ($by[$parent] ?? [] as $t) {
                $name = html_entity_decode($t->name, ENT_QUOTES, 'UTF-8');
                $p = $path === '' ? $name : $path . ' › ' . $name;
                $list[] = ['id' => (int) $t->term_id, 'name' => $name, 'path' => $p, 'depth' => $depth, 'count' => (int) $t->count];
                $walk($t->term_id, $p, $depth + 1);
            }
        };
        $walk(0, '', 0);
        return $cache[$taxonomy] = $list;
    }

    public static function term_exists($taxonomy, $id) {
        if (!taxonomy_exists($taxonomy)) {
            return false;
        }
        $t = get_term((int) $id, $taxonomy);
        return $t && !is_wp_error($t);
    }
}
