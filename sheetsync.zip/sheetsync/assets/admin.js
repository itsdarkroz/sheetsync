jQuery(function ($) {
    const fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    /* =============== صفحه محصولات =============== */
    if ($('#ss-apply').length) {
        const $rows = () => $('.ss-row-check');
        const refreshCount = () => $('#ss-count').text('(' + fa($('.ss-row-check:checked').length) + ')');

        $('#ss-check-all').on('change', function () { $rows().prop('checked', this.checked); refreshCount(); });
        $(document).on('change', '.ss-row-check', refreshCount);
        $('#ss-pick-pending').on('click', function () {
            $rows().each(function () {
                const st = $(this).closest('tr').data('state');
                $(this).prop('checked', st === 'new' || st === 'changed');
            });
            refreshCount();
        });

        $('#ss-apply').on('click', async function () {
            const ids = $('.ss-row-check:checked').map((_, e) => e.value).get();
            if (!ids.length) { alert('حداقل یک محصول را تیک بزنید.'); return; }
            const $btn = $(this).prop('disabled', true);
            const $box = $('#ss-progress').prop('hidden', false);
            const $bar = $box.find('.ss-bar > span').css('width', '0');
            const $txt = $box.find('.ss-progress-text');
            const $res = $box.find('.ss-result').empty();
            let done = 0, ok = 0; const errors = [], notes = [];

            for (let i = 0; i < ids.length; i += 5) {
                const part = ids.slice(i, i + 5);
                try {
                    const r = await $.post(SheetSync.ajax, { action: 'sheetsync_apply', nonce: SheetSync.nonce, ids: part });
                    if (r && r.success) {
                        r.data.results.forEach(function (x) {
                            if (x.ok) { ok++; (x.notes || []).forEach((n) => notes.indexOf(n) < 0 && notes.push(n)); }
                            else errors.push((x.sku ? x.sku + ': ' : '') + (x.msg || 'خطا'));
                        });
                    } else { part.forEach(() => errors.push('پاسخ نامعتبر از سرور')); }
                } catch (e) { part.forEach(() => errors.push('خطای ارتباط با سرور')); }
                done += part.length;
                $bar.css('width', Math.round(done / ids.length * 100) + '%');
                $txt.text('در حال آپدیت… ' + fa(done) + ' از ' + fa(ids.length));
            }

            $txt.text('پایان: ' + fa(ok) + ' محصول آپدیت شد' + (errors.length ? '، ' + fa(errors.length) + ' خطا' : '') + '.');
            let html = '';
            if (errors.length) html += '<strong style="color:#b32d2e">خطاها</strong><ul>' + errors.slice(0, 15).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>';
            if (notes.length) html += '<strong style="color:#8a5a00">هشدارها</strong><ul>' + notes.slice(0, 15).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>';
            html += '<button type="button" class="button button-primary" id="ss-reload">نمایش لیست به‌روز</button>';
            $res.html(html);
            $('#ss-reload').on('click', () => location.reload());
            $btn.prop('disabled', false);
        });
    }

    /* =============== صفحه یکسان‌سازی =============== */
    if (typeof SheetSync.terms === 'undefined') return;
    const T = SheetSync.terms, X = SheetSync.taxes;

    const dests = ($card) => $card.find('.ss-chip input:checked').map((_, e) => e.value).get();

    function optionsFor(ds, selected) {
        let html = '<option value="">— انتخاب کنید —</option>';
        const group = ds.length > 1;
        ds.forEach(function (tax) {
            if (group) html += '<optgroup label="' + esc((X[tax] || {}).label || tax) + '">';
            (T[tax] || []).forEach(function (t) {
                const v = tax + '|' + t.id;
                html += '<option value="' + esc(v) + '"' + (v === selected ? ' selected' : '') + '>' + esc(t.path) + '</option>';
            });
            if (group) html += '</optgroup>';
        });
        return html;
    }

    function rebuild($card) {
        const ds = dests($card);
        $card.find('select.ss-term').each(function () {
            const $s = $(this);
            const cur = $s.data('val') || '';
            if (!ds.length) {
                $s.html('<option value="">ابتدا بخش ۱ را انتخاب کنید</option>').prop('disabled', true);
            } else {
                $s.html(optionsFor(ds, cur)).prop('disabled', false);
                $s.data('val', $s.val() || '');
            }
        });
        update($card);
    }

    function update($card) {
        const $trs = $card.find('.ss-vtable tbody tr');
        let mapped = 0, total = 0;
        $trs.each(function () {
            const $tr = $(this);
            const has = $tr.find('select.ss-term').filter(function () { return !!$(this).val(); }).length > 0;
            $tr.toggleClass('is-mapped', has).toggleClass('is-unmapped', !has);
            if (!$tr.hasClass('is-stale')) { total++; if (has) mapped++; }
        });
        $card.find('.ss-prog').text(fa(mapped) + ' از ' + fa(total));
        $card.find('.ss-mini .ss-bar > span').css('width', (total ? Math.round(mapped / total * 100) : 0) + '%');
        const enabled = $card.find('.ss-enable').is(':checked');
        const $st = $card.find('.ss-status').removeClass('ss-b-ok ss-b-warn ss-b-muted');
        if (!enabled) $st.addClass('ss-b-muted').text('نادیده گرفته می‌شود');
        else if (!dests($card).length) $st.addClass('ss-b-warn').text('بدون مقصد');
        else if (mapped < total) $st.addClass('ss-b-warn').text(fa(total - mapped) + ' نگاشت‌نشده');
        else $st.addClass('ss-b-ok').text('کامل');
        $card.toggleClass('is-off', !enabled);
        applyFilter($card);
        let un = 0;
        $('.ss-col:not(.is-off) .ss-vtable tbody tr:not(.is-stale).is-unmapped').each(() => un++);
        $('#ss-unmapped-total').text(un);
    }

    function applyFilter($card) {
        const f = $card.find('.ss-filter .is-active').data('f') || 'all';
        $card.find('.ss-vtable tbody tr').each(function () {
            const $tr = $(this);
            $tr.toggle(f === 'all' || (f === 'mapped' && $tr.hasClass('is-mapped')) || (f === 'unmapped' && $tr.hasClass('is-unmapped')));
        });
    }

    $('.ss-col').each(function () { rebuild($(this)); });

    $(document).on('change', '.ss-chip input', function () { rebuild($(this).closest('.ss-col')); });
    $(document).on('change', '.ss-enable', function () { update($(this).closest('.ss-col')); });
    $(document).on('change', 'select.ss-term', function () { $(this).data('val', this.value); update($(this).closest('.ss-col')); });
    $(document).on('click', '.ss-filter button', function () {
        const $card = $(this).closest('.ss-col');
        $(this).addClass('is-active').siblings().removeClass('is-active');
        applyFilter($card);
    });
    $(document).on('click', '.ss-add', function () {
        const $card = $(this).closest('.ss-col');
        $(this).siblings('.ss-sels').append('<div class="ss-valsel"><select class="ss-term" data-val=""></select><button type="button" class="ss-rm" title="حذف">×</button></div>');
        rebuild($card);
    });
    $(document).on('click', '.ss-rm', function () {
        const $card = $(this).closest('.ss-col');
        $(this).closest('.ss-valsel').remove();
        update($card);
    });
    $(document).on('click', '.ss-del-row', function () {
        const $card = $(this).closest('.ss-col');
        $(this).closest('tr').remove();
        update($card);
    });

    $(document).on('click', '.ss-save-col', function () {
        const $btn = $(this), $card = $btn.closest('.ss-col'), $msg = $card.find('.ss-msg');
        const values = [];
        $card.find('.ss-vtable tbody tr').each(function () {
            const $tr = $(this);
            const to = $tr.find('select.ss-term').map((_, s) => s.value).get().filter(Boolean);
            values.push({ hash: $tr.data('hash'), label: $tr.data('label'), to: to });
        });
        const payload = {
            label: $card.data('label'),
            enabled: $card.find('.ss-enable').is(':checked'),
            dests: dests($card),
            values: values
        };
        $btn.prop('disabled', true);
        $msg.removeClass('is-ok is-err').text('در حال ذخیره…');
        $.post(SheetSync.ajax, { action: 'sheetsync_save_column', nonce: SheetSync.nonce, payload: JSON.stringify(payload) })
            .done(function (r) {
                if (r && r.success) { $msg.addClass('is-ok').text('✓ ' + r.data.msg); update($card); }
                else { $msg.addClass('is-err').text((r && r.data && r.data.msg) || 'ذخیره نشد.'); }
            })
            .fail(function () { $msg.addClass('is-err').text('خطای ارتباط با سرور.'); })
            .always(function () { $btn.prop('disabled', false); });
    });
});
